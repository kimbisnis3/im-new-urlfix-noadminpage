<div class="content">
<div class="container">
<h3 class="titles">PAYMENT</h3>
<div class="center">
    <form action='<?php echo base_url();?>billing/inputmetodepembayaran' method='post' name='process'>
    <div class="form-group"> 
        <select class="form-control" name="payment" class="" style="width: 100%;">
		<?php
		foreach($mpayment as $t)
		{
		?>
		<option value="<?php echo $t->kode ?>">
			<?php echo $t->nama ?> - <?php echo $t->norek ?>
		</option>
		<?php }?>
	</select>
	</div>
        <button type="submit" class="btn btn-primary">selanjutnya</button>
        <!--<p class="message">Bukan Member? <a href="#">Hubungi Admin</a></p>-->
    </form>
</div>
</div>
</div>

