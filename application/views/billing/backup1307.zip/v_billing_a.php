<div class="content">
<div class="container">
<h3 class="titles">CUSTOMER LOGIN</h3>
<body>
	<div class="login-page container-fluid">
		<div class="form container-fluid">
			<div>
			<?php echo $this->session->flashdata('message');?>
			</div>
			<div class="center" style="border: 2px solid #777; padding: 10px;">
			<form action='<?php echo base_url();?>login/aksi_login' method='post' name='process'>
			<div class="form-group"> 
				<input type="text" name="nama" class="form-control" placeholder="username"/ required>
			</div>
			<div class="form-group"> 
				<input type="password" name="pass" class="form-control" placeholder="password" required />
			</div>
			<div class="row">
			<div class="col-md-6">
				<button type="submit" class="btn btn-success">login</button>
			</div>
			<div class="col-md-6">
				<a href="<?php echo base_url('register'); ?>">Daftar</a>
			</div>
			</div>
				<!--<p class="message">Bukan Member? <a href="#">Hubungi Admin</a></p>-->

			</form>
			</div>
		</div>
	</div>
</body>
</div>
</div>