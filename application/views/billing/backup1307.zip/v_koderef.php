<div class="content">
    <div class="container">
        <h3 class="titles">ORDER SUCCESS</h3>
        <div class="center">
        <p>Referensi Kode : <strong><?php echo $this->session->userdata("koderef"); ?></strong></p>
        <p>Gunakan Referensi Kode untuk berita transfer saat melakukan pembayaran.</p>
        <p>Jika sudah melakukan pembayaran silahkan menghubungi sales kami.</p>
        </div>
    </div>
</div>