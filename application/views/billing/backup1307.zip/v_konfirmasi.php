<div class="content">
    <div class="container">
        <h3 class="titles">CONFIRMATION</h3>
        <div class="center">
            <div class="box">
                <?php
                if ($cart = $this->cart->contents()) {
                ?><table>
                    <tr>
                        <td>
                            <h3><u></u></h3>
                        </td>
                    </tr>
                    <tr>
                        <th>Jumlah</th>
                        <th>Nama Barang</th>
                        <th>Total</th>
                    </tr>
                    <?php
                    foreach ($cart as $contents) {
                    $p = $contents['price'];
                    $q = $contents['qty'];
                    $price = $p*$q;
                    ?><tr>
                        <form method="post" action="<?php echo base_url('shop/update/'.$contents["rowid"]); ?>">
                            <input type="hidden" value="<?php echo $contents["rowid"]; ?>" name="rowid">
                            <td><input type="text" value="<?php echo $contents['qty']; ?>" name="qty"></td>
                            <td><?php echo $contents['name']; ?></td>
                            <td>Rp. <?php echo number_format($price); ?></td>
                        </tr>
                        <?php } ?>
                        <td></td>
                        <a href="<?php echo base_url('billing/order'); ?>"></a>
                    </form>
                </table> <?php
                // redirect(base_url('/index.php/Cart/Cart_view'));
                }
                ?>
                <div>
                    <strong>
                    Nama Customer :
                    </strong>
                    <?php echo $this->session->userdata("namacustomer"); ?>
                </div>
                <div>
                    <strong>
                    Alamat Kirim :
                    </strong>
                    <?php echo $this->session->userdata("alamatkirim"); ?>
                </div>
                <div>
                    <strong>
                    Nama Penerima :
                    </strong>
                    <?php echo $this->session->userdata("penerima"); ?>
                </div>
                <div>
                    <strong>
                    Jenis Pembayaran :
                    </strong>
                    <?php echo $this->session->userdata("namapayment"); ?>
                </div>
                <div>
                    <strong>
                    Nomer Rekening :
                    </strong>
                    <?php echo $this->session->userdata("norek"); ?>
                </div>
                <div>
                    <strong>
                    Ekspedisi :
                    </strong>
                    <?php echo $this->session->userdata("namaekspedisi"); ?>
                </div>
                <div>
                    <strong>
                    Jenis Pengiriman :
                    </strong>
                    <?php echo $this->session->userdata("namashipment"); ?>
                </div>
                <div>
                    <strong>
                    Biaya Pengiriman :
                    </strong>
                    Rp. 
                    <?php echo number_format($this->session->userdata("harga")); ?>
                </div>
                <div>
                    <strong>
                    Total Belanja :
                    </strong>
                    Rp. <?php echo $this->cart->format_number($this->cart->total()); ?>
                </div>
                <div>
                    <strong>
                    Total Belanja + Biaya Pengiriman:
                    </strong>
                    Rp. <?php $total = $this->cart->total();
                            $biaya = $this->session->userdata("harga");
                            $q = $total+$biaya;
                            echo number_format($q);
                    ?>
                </div>
                <a href="<?php echo base_url('billing/order') ?>" type="button" class="btn btn-success"> ORDER </a>
            </div>
        </div>
    </div>
</div>